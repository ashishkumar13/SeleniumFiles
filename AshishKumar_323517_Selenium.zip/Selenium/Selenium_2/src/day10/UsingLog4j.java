package day10;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class UsingLog4j {
	
	Logger log;
	
	@Test
	public void test_1() {
		String expected = "Hello Moto";
		
		Assert.assertEquals("Hello Moto", expected);
		
		log = Logger.getLogger("devpinoyLogger");
		log.info("Test1 executed");
		
	}
	
	@Test
	public void test_2() {
		String expected = "Hello Moto";
		SoftAssert sa = new SoftAssert();
		
		sa.assertEquals("Hello Motorola", expected);
		
		log.info("Test2 executed");
		sa.assertAll();
	}
	
}
