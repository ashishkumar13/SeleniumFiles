package day10.extra;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FbHomepage {
	WebDriver dr;
	
	By profileNameXpath = By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span");
	
	public FbHomepage(WebDriver dr) {
		this.dr = dr;
	}
	
	public String getProfileName() {
		return dr.findElement(profileNameXpath).getText();
	}
	
}
