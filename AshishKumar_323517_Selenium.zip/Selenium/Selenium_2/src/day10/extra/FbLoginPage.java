package day10.extra;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FbLoginPage {
	WebDriver dr;
	By emailXpath = By.xpath("//*[@id=\"email\"]");
	By passwordXpath = By.xpath("//*[@id=\"pass\"]");
	By loginXpath = By.xpath("//*[@id=\"loginbutton\"]");
	
			
	
	public FbLoginPage(WebDriver dr) {
		this.dr = dr;
	}
	
	public void enterEmail(String email) {
		dr.findElement(emailXpath).sendKeys(email);
	}
	
	public void enterPassword(String password) {
		dr.findElement(passwordXpath).sendKeys(password);
	}
	
	public void clickLogin() {
		dr.findElement(loginXpath).click();
	}
	
	public void doLogin(String email, String password) {
		this.enterEmail(email);
		this.enterPassword(password);
		this.clickLogin();
	}
	
	public String getTitle() {
		return dr.getTitle();
	}

	
}
