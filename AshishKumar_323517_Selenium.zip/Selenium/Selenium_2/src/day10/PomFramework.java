package day10;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import day10.extra.FbHomepage;
import day10.extra.FbLoginPage;



// POM = Page Object Model
public class PomFramework {
	WebDriver dr;
	
	
	FbLoginPage loginpage;
	FbHomepage homepage;
	@BeforeClass
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get("https://www.facebook.com");
	}
	
  @Test(priority = 0)
  public void testLoginPage() {
	  loginpage = new FbLoginPage(dr);
	  
	  String pageTitle = loginpage.getTitle();
	  System.out.println("Title: "+ pageTitle);
	  
	  Assert.assertTrue(pageTitle.contains("Facebook"));
  }
  
  @Test(priority = 1)
  public void testHomePage() {
	  loginpage.doLogin("girishindia95@gmail.com", "mynewp@55");
	  homepage = new FbHomepage(dr);
	  String actualProName = homepage.getProfileName();
	  
	  System.out.println("Actual Profile Name: " + actualProName);
	  
	  Assert.assertTrue(actualProName.contains("Girish"));
  }
	
  
}
