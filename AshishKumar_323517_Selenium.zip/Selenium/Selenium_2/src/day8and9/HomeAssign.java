package day8and9;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class HomeAssign extends HomeAssignExcel{
  
	
	@Test(dataProvider = "datasupply")
	public void demoWebLogin(String email, String password, String expected) {
		String actual = login(email, password);
		
		Assert.assertEquals(actual, expected);
	}
	
	@DataProvider( name = "datasupply")
	public String[][] data() {
		
		String logindata[][] = readExcel();
		
		return logindata;
	}
}
