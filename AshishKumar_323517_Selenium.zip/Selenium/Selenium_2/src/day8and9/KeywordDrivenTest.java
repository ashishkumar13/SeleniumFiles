package day8and9;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//Keyword Driven Framework driverscript

public class KeywordDrivenTest {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("https://www.facebook.com");
		ExcelIO ex = new ExcelIO();
		ArrayList<TestCase> dataList = ex.readExcel();
		
		WebelementMethods methods = new WebelementMethods();
		
		for(int i = 0; i< dataList.size(); i++) {

			TestCase tcase = dataList.get(i);
			
			switch(tcase.getKeyword()) {
			
			case "launchBrowserWithURL":
				methods.launchUrl(dr, tcase.getTestData());
				break;
			
			case "EnterText":
				methods.enterText(dr, tcase.getXpath(), tcase.getTestData());
				break;
				
			case "click":
				methods.click(dr, tcase.getXpath());
				break;
			case "verify":
				methods.verify(dr, tcase.getXpath(), tcase.getTestData());
				break;
			default:
				break;
			}
		}
		
		
	}
	

}
