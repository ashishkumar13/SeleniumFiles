package day8and9;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ddfw_dataProvider {
	
  @Test(dataProvider = "logindataprovider")
  public void login(String eid, String pwd, String er) {
	
	  System.out.println("eid: "+ eid + " Password: "+ pwd + " exp result: "+ er);
	  Assert.assertEquals("Girish", er);
  }
  @DataProvider(name = "logindataprovider")
  public String[][] get_testdata(){
	  String [][]logintestdata = {
			  						{"girishindia95@gmail.com", "mynewp@55", "Girish"},
			  						{"girishindia95@gmail.com", "mynewp@55", "Girish1"}
	  							 };
	  
	  return logintestdata;
  }
  
}
