package day8and9;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HomeAssignExcel {
	public String[][] readExcel() {
		int i;
		String [][]data = new String[4][3];
		
		File file = new File("DemoLogin.xlsx");
		
		try {
			FileInputStream fis = new FileInputStream(file);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row;
			XSSFCell cell;
			for(i=1; i<5; i++) {
				
				row = sh.getRow(i);
				
				cell = row.getCell(0);
				data[i-1][0] = cell.getStringCellValue();
				
				cell = row.getCell(1);	
				if(cell.getCellType() == 1) {
					data[i-1][1] = cell.getStringCellValue();
				}
				else {
					data[i-1][1]  = (Long.toString((long) cell.getNumericCellValue()));
					
				}
				
				cell = row.getCell(2);
				data[i-1][2] = cell.getStringCellValue();							
				
			}
			
			wb.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return data;
		
	}
	
	public String login(String email, String password) {
		String actualResult = "";
		String actualResult2;
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		
		WebElement emailField = dr.findElement(By.xpath("//*[@id=\"Email\"]"));
		WebElement passField = dr.findElement(By.xpath("//*[@id=\"Password\"]"));
		
		WebElement login = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"));
		emailField.sendKeys(email);
		passField.sendKeys(password);
		login.click();	
		boolean b1;
		
		try {
			
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
			if(b1) {
				actualResult += dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			WebElement proName = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
			actualResult2 = proName.getText();
			if(!actualResult2.equals("Register")) {
				actualResult = actualResult2;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		dr.quit();
		
		return actualResult;		
		
	}
}
	

