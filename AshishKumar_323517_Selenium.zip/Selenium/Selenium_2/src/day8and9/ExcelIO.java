package day8and9;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelIO {
	

	public ArrayList<TestCase> readExcel() {
		int i;
		ArrayList<TestCase> dataList = new ArrayList<TestCase>();
		
		File file = new File("KeywordDrivenData.xlsx");
		
		try {
			FileInputStream fis = new FileInputStream(file);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row;
			XSSFCell cell;
			for(i=1; i<6; i++) {
				TestCase tc = new TestCase();
				
				row = sh.getRow(i);
				
				cell = row.getCell(1);
				tc.setKeyword(cell.getStringCellValue());
				
				cell = row.getCell(2);
				tc.setXpath(cell.getStringCellValue());
				
				cell = row.getCell(3);	
				if(cell.getCellType() == 1) {
					tc.setTestData(cell.getStringCellValue());
				}
				else {
					tc.setTestData(Long.toString((long) cell.getNumericCellValue()));
					
				}
						
				
				dataList.add(tc);
			}
			
			wb.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dataList;
		
	}

	
}
