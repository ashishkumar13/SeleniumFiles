package day8and9;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class WebelementMethods {
	
	public void launchUrl(WebDriver dr, String testData) {
		dr.get(testData);
	}
	
	public void enterText(WebDriver dr, String xpath, String testData) {
		dr.findElement(By.xpath(xpath)).sendKeys(testData);
		
	}
	
	public void click(WebDriver dr, String xpath) {
		dr.findElement(By.xpath(xpath)).click();
	}
	
	public void verify(WebDriver dr, String xpath, String testData) {
		String ar = "";
		try {
			ar = dr.findElement(By.xpath(xpath)).getText();
		}catch( Exception e) {
			e.printStackTrace();
		}	
		
		if(ar.equals(testData)) {
			System.out.println("Pass");
		}
		else {
			System.out.println("Fail");
		}
	}

}
