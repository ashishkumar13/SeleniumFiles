package day4.extra;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import day4.LoginDetail;





public class ExcelDemoLogin extends LoginDetail {
	
	public ArrayList<LoginDetail> readExcel() {
		int i;
		ArrayList<LoginDetail> userList = new ArrayList<LoginDetail>();
		
		File file = new File("DemoLogin.xlsx");
		
		try {
			FileInputStream fis = new FileInputStream(file);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row;
			XSSFCell cell;
			for(i=1; i<5; i++) {
				LoginDetail user = new LoginDetail();
				
				row = sh.getRow(i);
				
				cell = row.getCell(0);
				user.setEmail(cell.getStringCellValue());
				
				cell = row.getCell(1);
				user.setPassword(cell.getStringCellValue());
				
				cell = row.getCell(2);
				user.setExpectedResult(cell.getStringCellValue());
				
				userList.add(user);
				
				wb.close();
			}
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userList;
		
	}

	public void writeExcel(ArrayList<LoginDetail> usersDetails) {
		
		int i, j = 1;
		LoginDetail user;
		File file = new File("DemoLogin.xlsx");
		try {
			FileInputStream fis = new FileInputStream(file);
			
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			XSSFRow row ;
			XSSFCell cell1, cell2;
			FileOutputStream fos;
			for(i = 0; i<4; i++) {
				user = usersDetails.get(i);
				row = sh.getRow(j++);
				
				cell1 = row.createCell(3);
				cell1.setCellValue(user.getActualResult());
				
				cell2 = row.createCell(4);
				cell2.setCellValue(user.getStatus());
				
				fos = new FileOutputStream(file);
				wb.write(fos);
				wb.close();
			}
			
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
}
