package day4;

import java.util.ArrayList;

import day4.extra.ExcelDemoLogin;

public class LoginMain {
	public static void main(String[] args) {
		
		ExcelDemoLogin exLog = new ExcelDemoLogin();
		
		ArrayList<LoginDetail> userDetails = new ArrayList<LoginDetail>();
		
		userDetails = exLog.readExcel();
		for(int i = 0; i<4; i++) {
			LoginDetail user = userDetails.get(i);
			
			user.login();
			user.Display();
		}
		
		exLog.writeExcel(userDetails);
	}
}
