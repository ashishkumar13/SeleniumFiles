package day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class LoginDetail {
	
	private String email;
	private String password;
	private String expectedResult;
	private String actualResult;	
	private String status;
	
	
	public void login() {
		actualResult = "";
		String actualResult2;
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		
		WebElement emailField = dr.findElement(By.xpath("//*[@id=\"Email\"]"));
		WebElement passField = dr.findElement(By.xpath("//*[@id=\"Password\"]"));
		
		WebElement login = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"));
		emailField.sendKeys(email);
		passField.sendKeys(password);
		login.click();	
		boolean b1;
		
		try {
			
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
			if(b1) {
				actualResult += dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
				
			}		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).isDisplayed();
			
			if(b1) {
				actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div")).getText();
				
			}	
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		try {
			WebElement proName = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a"));
			actualResult2 = proName.getText();
			if(actualResult2.equals(expectedResult)) {
				actualResult = actualResult2;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		if( actualResult.equals(expectedResult)) {
			status = "Pass";
		}
		else {
			status = "Fail";
		}	
		
		dr.quit();		
		
	}
	
	public void Display() {
		System.out.println("Email: "+ email+ "\nPass: "+password + "\nExpectedResult: "
				+ expectedResult + "\nActualResult: "+ actualResult+ "\nStatus: "+ status);
		System.out.println("===============================================================================");
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getExpectedResult() {
		return expectedResult;
	}

	public void setExpectedResult(String expResult) {
		this.expectedResult = expResult;
	}

	public String getActualResult() {
		return actualResult;
	}

	public String getStatus() {
		return status;
	}
	
	
	

}
