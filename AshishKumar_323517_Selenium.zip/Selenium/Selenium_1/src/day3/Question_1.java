package day3;

import java.util.ArrayList;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Question_1  {
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		String actualtitle=dr.getTitle();
		String exptitle="Demo Web Shop";
		if(actualtitle.equals(exptitle)) {
			System.out.println("pass");
		}
		else {
			System.out.println("fail");
		}
		dr.findElement(By.className("ico-register")).click();
		ArrayList<WebElement> arr=(ArrayList<WebElement>) dr.findElements(By.name("Gender"));
		arr.get(0).click();
		dr.findElement(By.id("FirstName")).sendKeys("Hello");
		dr.findElement(By.id("LastName")).sendKeys("World");
		dr.findElement(By.id("Email")).sendKeys("abcde124d34@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("abcdef");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("abcdef");
		dr.findElement(By.id("register-button")).click();	
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
}
