package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Question_5 {
	
	public void Addtocart(WebDriver dr,int r,int c) {
		dr.findElement(By.name("category_id")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[1]/td/select/option[3]")).click();
		
		dr.findElement(By.name("DoSearch")).click();
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr["+r+"]/td["+c+"]/b/a")).click();
		
		dr.findElement(By.name("quantity")).clear();
		dr.findElement(By.name("quantity")).sendKeys("2");
		dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")).click();
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[1]")).click();
	}
	
	public String substring(String str) {
		String st=str.substring(1, str.length());
		return st;
	}
	
	public static void main(String args[]) {
		Question_5 wb=new Question_5();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/Store/Default.php");
		String actualTitle=dr.getTitle();
		String expTitle="Online Bookstore";
		
		if(actualTitle.equals(expTitle)) {
			System.out.println("pass");
		}
		else
			System.out.println("fail");
		
		wb.Addtocart(dr,1,2);
		wb.Addtocart(dr,3,2);
		wb.Addtocart(dr,5,2);
		dr.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/a[3]")).click();
		
		float total=0;
		float finaltotal=0;
		
		int qty=2;
		for(int r=2;r<=4;r++) {
			
	         String xpath1="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+r+"]/td[2]";
				String stra=dr.findElement(By.xpath(xpath1)).getText();
				String str1=wb.substring(stra);
				float price1=Float.parseFloat(str1);
				//System.out.println(price1);
				total=price1*qty;
				//System.out.println(total);
				String xpath2="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/form[1]/table[2]/tbody/tr["+r+"]/td[4]";
				String strb=dr.findElement(By.xpath(xpath2)).getText();
				String str2=wb.substring(strb);
				float price2=Float.parseFloat(str2);
				if(total==price2) {
					System.out.println("passing");
				}
				else 
					{System.out.println("failing");
					}
				finaltotal=finaltotal+total;
	
		}
		System.out.println(finaltotal);
	//System.out.println(dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p/text()")).getText());
		String str="/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p";
	String stri=dr.findElement(By.xpath(str)).getText();
	str=stri.substring(8);
	float actualtotal=Float.parseFloat(str);
		if(finaltotal==actualtotal) {
		System.out.println("Finally passing");
	}
	
	}
}
