package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Question_3 {
	public static void main(String args[]) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("abcde124d34@gmail.com");
		String email="abcde124d34@gmail.com";
		dr.findElement(By.id("Password")).sendKeys("abcdef");
		dr.findElement(By.xpath("//input[@value='Log in']")).click();
		String Actualid=dr.findElement(By.className("account")).getText();
		if(email.equals(Actualid)) {
			System.out.println("pass");
		}
		else System.out.println("fail");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
	}
}