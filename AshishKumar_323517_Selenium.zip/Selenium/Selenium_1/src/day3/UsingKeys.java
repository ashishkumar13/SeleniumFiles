package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class UsingKeys {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://www.facebook.com/");
		
		WebElement fname = dr.findElement(By.xpath("//*[@id=\"u_0_l\"]"));
		WebElement lname = dr.findElement(By.xpath("//*[@id=\"u_0_n\"]"));
		
		Actions act = new Actions(dr);
		
		Action set1 = act
				.moveToElement(fname)
				.click(fname)
				.sendKeys("Whats Up!")
				.keyDown(fname, Keys.CONTROL)
				.sendKeys("a")
				.sendKeys("c")
				.keyUp(fname, Keys.CONTROL)
				.build();
		
		set1.perform();
		
		Action set2 = act
				.moveToElement(lname)
				.click(lname)
				.keyDown(lname, Keys.CONTROL)
				.sendKeys("v")
				.keyUp(lname, Keys.CONTROL)
				.build();
		
		set2.perform();
				
		
	}
}
