package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class HoverExample {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/");
		
		WebElement computers = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/a"));
		
		
		
		Actions act = new Actions(dr);
		
		Action set1 = act
				.moveToElement(computers)
				.build();
		
		set1.perform();
		
		WebElement accessories = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[2]/ul/li[3]/a"));
		
		Action set2 = act
				.moveToElement(accessories)
				.click()
				.build();
		
		set2.perform();
		// 
		WebElement electronics = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/a"));
		Action set3 = act
				.moveToElement(electronics)
				.build();
		
		set3.perform();
		
		WebElement cellPhones = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[2]/ul[1]/li[3]/ul/li[2]/a"));
		
		Action set4 = act
				.moveToElement(cellPhones)
				.click()
				.build();
		
		set4.perform();
		
	}
}
