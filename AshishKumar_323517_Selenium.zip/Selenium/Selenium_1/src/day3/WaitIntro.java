package day3;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

///////////  Implicit and Explicit Wait

public class WaitIntro {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://www.facebook.com/");
		
		// Implicit Wait
		// dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		// Explicit Wait
		WebDriverWait wt = new WebDriverWait(dr, 10);
		wt.until(ExpectedConditions.elementToBeClickable(By.xpath("abc")));
		
		dr.findElement(By.xpath("abc"));
		
		// Navigation 
//		dr.navigate().back();
//		dr.navigate().forward();
//		dr.navigate().refresh();
//		dr.navigate().to(url);
		
	}
}
