package day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTables {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
		for (int col = 1; col <= 3; col++) {
			String xpath1 = "//*[@id=\"customers\"]/tbody/tr[1]/th[" + col + "]";

			String str1 = dr.findElement(By.xpath(xpath1)).getText();
			System.out.print(str1 + "  ");
		}
		System.out.println();
		for (int r = 2; r <= 7; r++) {
			for (int c = 1; c <= 3; c++) {
				String xpath = "//*[@id=\"customers\"]/tbody/tr[" + r + "]/td[" + c + "]";
				String str = dr.findElement(By.xpath(xpath)).getText();
				System.out.print(str + "  ");
			}
			System.out.println();
		}
		dr.close();
	}
}