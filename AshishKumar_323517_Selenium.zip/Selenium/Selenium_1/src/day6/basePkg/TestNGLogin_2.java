package day6.basePkg;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNGLogin_2 extends LoginNg_2 {
	
	WebDriver dr;
	@BeforeMethod
	public void launch() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		this.dr = dr;
		dr.get("http://demowebshop.tricentis.com/login");		
		
	}
	
	@Test
	public void tc1() {
		String expected = "Please enter a valid email address.", actual;
		actual = login(dr, "a", "adasdd");
		
		Assert.assertEquals(actual, expected);
	}
	
	@Test
	public void tc2() {
		String expected = "Login was unsuccessful. Please correct the errors and try again.\n" + 
				"No customer account found", actual;
		actual = login(dr, "", "");
		
		Assert.assertEquals(actual, expected);
	}
	
	@Test
	public void tc3() {
		String expected = "Login was unsuccessful. Please correct the errors and try again.\n" + 
				"The credentials provided are incorrect", actual;
		actual = login(dr, "abc@xyz.com", "amck");
		
		Assert.assertEquals(actual, expected);
	}
	
	
}
