package day6.basePkg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNGLogin_1 extends LoginTest{
  @Test
  public void tc1() {
	  System.out.println("In TC1");
	  String expected = "Please enter a valid email address.", actual;
	  actual = login();
	  
	  Assert.assertEquals(actual, expected);
  }
  @Test
  public void tc2() {
	  System.out.println("In TC2");
	  String expected = "Please enter a valid email .", actual;
	  actual = login();
	  
	  Assert.assertEquals(actual, expected);
  }
  
}
