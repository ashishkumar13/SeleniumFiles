package day6.basePkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {
	
	private String email = "a";
	private String password = "shxb";
	
	private String actualResult;	
		
	
	
	public String login() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("http://demowebshop.tricentis.com/login");
		
		WebElement emailField = dr.findElement(By.xpath("//*[@id=\"Email\"]"));
		WebElement passField = dr.findElement(By.xpath("//*[@id=\"Password\"]"));
		
		WebElement login = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input"));
		emailField.sendKeys(email);
		passField.sendKeys(password);
		login.click();	
		boolean b1;
		
		b1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).isDisplayed();
		if(b1) {
			actualResult = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[2]/span/span")).getText();
			
		}	
		dr.quit();
		return actualResult;
	}
	
}
