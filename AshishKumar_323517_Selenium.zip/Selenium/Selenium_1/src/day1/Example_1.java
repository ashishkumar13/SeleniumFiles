package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/// Login in facebook
public class Example_1 {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();	
		dr.get("https://www.facebook.com");
		
		
		dr.findElement(By.id("email")).sendKeys("girishindia95@gmail.com");
		
//		OR
//		
//		WebElement email = dr.findElement(By.id("email"));
//		email.sendKeys("xyz...");
		
		
		dr.findElement(By.id("pass")).sendKeys("newfbp@55");
		
		dr.findElement(By.id("loginbutton")).click();
		
		String profileName, title = dr.getTitle();
		
		profileName = dr.findElement(By.className("_1vp5")).getText();
		
		System.out.println("Title: "+title+"\nProfile Name: "+profileName);
		
	}
}
