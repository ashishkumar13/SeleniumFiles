package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

/// trying out other function

public class FB_2 {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		
		WebDriver dr = new ChromeDriver();
		
		dr.get("https://www.facebook.com");
		
		WebElement day1 = dr.findElement(By.id("day"));
		
		Select sel1 =new Select(day1);
		 sel1.selectByVisibleText("17");
		
	}
}
