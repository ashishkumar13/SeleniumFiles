package day7;

import org.testng.annotations.Test;

import day5.alertDemo.Alert;

public class TestNGDemo_1 extends Alert{
	
	
  @Test
  public void tc1() {
	  System.out.println("TC1 ");
	  
	  performDelete("hcbsdkcbaskcb");
  }
  
  
  public void method() {
	  System.out.println("TC2 ");
  }
  
  @Test
  public void tc3() {
	  System.out.println("TC3 ");
  }
}
