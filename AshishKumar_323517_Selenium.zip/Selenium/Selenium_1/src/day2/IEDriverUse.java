package day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class IEDriverUse {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.ie.driver", "D:\\Drivers\\WebDrivers\\IEDriverServer.exe");
		
		WebDriver ieDr = new InternetExplorerDriver();
		
		ieDr.get("https://www.facebook.com");
		
	}
}
