package day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		WebDriver dr = new ChromeDriver();
		
		dr.get("https://www.facebook.com");
		
		// dr.findElement(By.cssSelector("input[type='submit']")).click();
		
		//WebElement bd = dr.findElement(By.xpath("//*[text() = 'Birthday']"));
//		WebElement bd = dr.findElement(By.xpath("//*[contains(text(), 'Create an account')]"));
		
		//  Axes methods :
		// i) Following
		// ii) Ancestor
		// iii) Child, etc
		
//		WebElement bd = dr.findElement(By.xpath("//input[@name='firstname']//following::input[2]"));
		
		WebElement bd = dr.findElement(By.xpath("//*[text() = 'Birthday']//ancestor::div[1]"));
		
		
		System.out.println(bd.getAttribute("class"));
	}
}
