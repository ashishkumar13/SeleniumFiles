package day2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxDriverUse {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.gecko.driver", "D:\\Drivers\\WebDrivers\\geckodriver.exe");
		
		WebDriver ieDr = new FirefoxDriver();
		
		ieDr.get("https://www.facebook.com");
		
	}
}
