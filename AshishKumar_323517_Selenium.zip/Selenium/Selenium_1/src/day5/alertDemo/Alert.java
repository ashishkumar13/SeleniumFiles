package day5.alertDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class Alert {
	
	WebElement textField, submit ;
	WebDriver dr;
	
	public Alert() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		dr = new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
		
		textField = dr.findElement(By.xpath("/html/body/form/table/tbody/tr[2]/td[2]/input"));		
		submit = dr.findElement(By.xpath("/html/body/form/table/tbody/tr[3]/td[2]/input[1]"));
	}
	
	public void performDelete(String customer) {
		textField.sendKeys(customer);
		submit.click();
		
		
		dr.switchTo().alert().accept();		
		dr.switchTo().alert().accept();
		System.out.println("in perform delete");
	}
	
	
	
	public void cancelDelete(String customer) {
		textField.sendKeys(customer);
		submit.click();
		
		
		dr.switchTo().alert().dismiss();		
		System.out.println("in cancel delete");
		
	}
	
	public void refreshPage() {
		dr.navigate().refresh();
	}
	
	
}
