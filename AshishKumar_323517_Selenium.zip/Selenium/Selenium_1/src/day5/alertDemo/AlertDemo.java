package day5.alertDemo;



public class AlertDemo {
	
	
	
	public static void main(String[] args) {
	
		Alert al = new Alert();
		
		al.cancelDelete("kcbaca");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		al.performDelete("dcjnsdjkcnajkcha");
		
	}
}
