package day5.testSuite_2;

import org.testng.annotations.Test;

import day5.alertDemo.Alert;

public class Tests_2 extends Alert{
  
	
	  @Test
	  public void tc1() {
		  System.out.println("TC1 ");
		  
		  performDelete("hcbsdkcbaskcb");
	  }
	  
	  @Test
	  public void tc3() {
		  System.out.println("TC3 ");
	  }
	
}
