package day5.testSuite_1;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Tests_1 {
		
	@Test
	public void tc1() {
		  
		  String er = "Noida", ar = "Noid" ;
		  SoftAssert sa = new SoftAssert();
		  
		  System.out.println("In TC1");
		  
		  sa.assertEquals(ar, er); // HardAssert will not execute statements following assert. while
		  							// in soft assert it does.
		  
		  System.out.println("After assert TC1");
		  
		  sa.assertAll();
	  }
	  
	  @Test
	  public void tc2() {
		  
		  String er = "Noida", ar = "Noida" ;
		  System.out.println("In TC2");
		  Assert.assertEquals(ar, er);
		  System.out.println("After assert TC2");
		  
	  }
	
}
